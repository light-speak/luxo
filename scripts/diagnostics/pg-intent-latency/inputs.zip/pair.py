import json
import os
import re
import subprocess
from decimal import Decimal
from statistics import median

PRODUCT = {"A": "d313f1aebcefb1106a0c230133bb64da662796d8", "B": "ecf4e236c68a5258c618e98477a9bb0ce61b4f54"}

COMPILED = {**PRODUCT, "A": "f87041ec1e4f832e9e674a3aae6ef95aa56affd5"}

LEAVES = tuple(f"{schema}/{action}" for schema in ("public", "quoted", "empty") for action in ("insert", "replace"))

COMPARISONS = ("AA", "AB", "BB")

BENCHMARK = "BenchmarkStoreMigrationAttemptSQL"

PKG = "github.com/light-speak/luxo/pkg/lux/pg/migrate"

COUNT = 12_000

PAIRS = 10

MEASUREMENT = re.compile(r"^Benchmark\S+-2\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$", re.M)

def schedule():
    for pair in range(PAIRS):
        for rotation in range(len(LEAVES)):
            leaf = LEAVES[(pair + rotation) % len(LEAVES)]
            for offset in range(len(COMPARISONS)):
                comparison = COMPARISONS[(pair + rotation + offset) % len(COMPARISONS)]
                order = (1, 0) if pair % 2 else (0, 1)
                yield leaf, comparison, pair + 1, order

def sample_command(path, leaf):
    pattern = "/".join("^" + re.escape(section) + "$" for section in (BENCHMARK, *leaf.split("/")))
    return [str(path), "-test.run=^$", "-test.bench=" + pattern, "-test.benchmem", "-test.count=1",
            "-test.cpu=2", f"-test.benchtime={COUNT}x", "-test.timeout=5s"]

def parse_sample(raw, leaf, goos, goarch, iterations=COUNT, verified_cpu=None):
    lines = raw.splitlines()
    rows = [line for line in lines if line.startswith("Benchmark")]
    expect = f"{BENCHMARK}/{leaf}-2"
    if len(rows) != 1 or rows[0].split()[0] != expect or lines[-1:] != ["PASS"]:
        raise RuntimeError(f"unexpected independent-process benchmark workload for {leaf}")
    match = MEASUREMENT.fullmatch(rows[0])
    if not match or int(match[1]) != iterations:
        raise RuntimeError(f"invalid iteration count or metrics for {leaf}")
    for key, value in (("goos", goos), ("goarch", goarch), ("pkg", PKG)):
        if [line.strip() for line in lines if line.startswith(key + ": ")] != [f"{key}: {value}"]:
            raise RuntimeError(f"unexpected benchmark environment for {leaf}: {key}")
    cpu = [line.removeprefix("cpu: ").strip() for line in lines if line.startswith("cpu: ")]
    # Go on Linux ARM64 may omit the CPU line. Keep process output
    # unchanged and use the separately verified host model in that case.
    if not cpu and verified_cpu is not None:
        cpu = [verified_cpu]
    if len(cpu) != 1 or not cpu[0] or (verified_cpu is not None and cpu[0] != verified_cpu):
        raise RuntimeError("benchmark process CPU identity is missing or differs from its verified host")
    return cpu[0], (Decimal(match[2]), int(match[3]), int(match[4]))

def collect(tools, binaries, evidence, verified_cpu=None):
    env = {key: value for key, value in os.environ.items() if not key.startswith(("LUXO_", "DATABASE_"))}
    env.update(LC_ALL="C", GOMAXPROCS="2", GOGC="100", GOMEMLIMIT="off", GODEBUG="", TMPDIR=str(tools.parent))
    cpu_name = None
    pairs = {}
    with (evidence / "raw.jsonl").open("w") as trace:
        for leaf, comparison, number, order in schedule():
            values = [None, None]
            for side in order:
                arm = comparison[side]
                info = binaries[arm]
                cmd = sample_command(tools / info["binary"], leaf)
                entry = {"leaf": leaf, "comparison": comparison, "pair": number, "side": side,
                         "order": order, "arm": arm, "args": cmd}
                try:
                    result = subprocess.run(cmd, env=env, cwd=tools, timeout=15, stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT, text=True)
                except subprocess.TimeoutExpired as error:
                    output = error.stdout or ""
                    if isinstance(output, bytes):
                        output = output.decode(errors="replace")
                    trace.write(json.dumps({**entry, "timedOut": True, "output": output}) + "\n")
                    trace.flush()
                    raise
                trace.write(json.dumps({**entry, "exit": result.returncode, "output": result.stdout}) + "\n")
                trace.flush()
                result.check_returncode()
                cpu, values[side] = parse_sample(result.stdout, leaf, info["goos"], info["goarch"], verified_cpu=verified_cpu)
                if cpu_name not in (None, cpu):
                    raise RuntimeError("CPU identity changed within paired diagnostic")
                cpu_name = cpu
            pairs.setdefault(leaf, {}).setdefault(comparison, []).append((order, *values))
    return cpu_name, pairs

def summary(samples):
    result = {}
    for leaf, comparisons in samples.items():
        result[leaf] = {}
        for comparison, pairs in comparisons.items():
            if len(pairs) != PAIRS:
                raise RuntimeError("pair inventory differs")
            deltas = [right[0] - left[0] for _, left, right in pairs]
            timings = {"median": str(median(deltas)), "maximumPositive": str(max(0, max(deltas))),
                       "medianWhenLeftFirst": str(median(y for y, (order, *_) in zip(deltas, pairs) if order[0] == 0)),
                       "medianWhenRightFirst": str(median(y for y, (order, *_) in zip(deltas, pairs) if order[0] == 1)),
                       "allSigned": list(map(str, deltas))}
            if comparison != "AB":
                timings["maximumReversePositive"] = str(max(0, -min(deltas)))
            result[leaf][comparison] = {
                "ns/op": timings,
                "B/op": [right[1] - left[1] for _, left, right in pairs],
                "allocs/op": [right[2] - left[2] for _, left, right in pairs],
            }
    return result
