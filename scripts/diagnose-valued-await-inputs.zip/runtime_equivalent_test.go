package generated

import (
	"context"
	"errors"
	"testing"

	luxerrors "github.com/light-speak/luxo/pkg/lux/errors"
)

type qualifiedResolver struct{}

func (qualifiedResolver) LoadValue(_ context.Context, value int64) (int64, error) {
	if value < 0 {
		return 0, luxerrors.BadRequest
	}
	return value * 2, nil
}

func BenchmarkAwaitRuntimeEquivalent(b *testing.B) {
	app := &App{Resolver: qualifiedResolver{}}
	for _, sample := range []struct {
		name       string
		input, out int64
		err        error
	}{
		{"normal", 21, 42, nil},
		{"error", -1, 0, luxerrors.BadRequest},
	} {
		b.Run(sample.name, func(b *testing.B) {
			ctx := b.Context()
			b.ReportAllocs()
			for b.Loop() {
				value, err := app.qualified(ctx, sample.input)
				if value != sample.out || !errors.Is(err, sample.err) {
					b.Fatal(value, err)
				}
			}
		})
	}
}
