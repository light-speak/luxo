package generated

import (
	"errors"
	"testing"

	luxerrors "github.com/light-speak/luxo/pkg/lux/errors"
)

func BenchmarkAwaitRuntimeCorrected(b *testing.B) {
	app := &App{}
	for _, sample := range []struct {
		name        string
		early, fail bool
		out         string
		err         error
	}{
		{"normal", false, false, "after", nil},
		{"early", true, false, "outer", nil},
		{"error", true, true, "", luxerrors.BadRequest},
	} {
		b.Run(sample.name, func(b *testing.B) {
			ctx := b.Context()
			b.ReportAllocs()
			for b.Loop() {
				value, err := app.corrected(ctx, sample.early, sample.fail)
				if value != sample.out || !errors.Is(err, sample.err) {
					b.Fatal(value, err)
				}
			}
		})
	}
}
