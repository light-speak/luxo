package codegen

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"testing"

	"github.com/light-speak/luxo/pkg/ast"
	"github.com/light-speak/luxo/pkg/semantic"
)

func qualifyAwaitShape() bool { return os.Getenv("LUXO_AWAIT_SHAPE_PROOF") == "1" }

func attestAwaitShape(b *testing.B, value any) {
	b.Helper()
	data, err := json.Marshal(value)
	if err != nil {
		b.Fatal(err)
	}
	fmt.Printf("await-shape %s %x\n", b.Name(), sha256.Sum256(data))
}

func attestAwaitGenerated(b *testing.B, input *semantic.Result, config GeneratorConfig) {
	b.Helper()
	generated, err := Generate(input, "generated", config)
	if err != nil {
		b.Fatal(err)
	}
	attestAwaitShape(b, generated.Files)
}

func attestAwaitFacade(b *testing.B, names []string, fields []*ast.FieldDecl) {
	b.Helper()
	var output strings.Builder
	for _, model := range names {
		defaultGenerator().generateQueryFacade(&output, model, fields, true)
	}
	attestAwaitShape(b, output.String())
}

func attestAwaitDemand[K comparable](b *testing.B, demands map[K]loadProjection) {
	b.Helper()
	shapes := make([]string, 0, len(demands))
	for key, value := range demands {
		astKey, err := json.Marshal(key)
		if err != nil {
			b.Fatal(err)
		}
		clients := []any{}
		if value.clientSelection != nil {
			for _, path := range value.clientSelection.paths {
				clients = append(clients, []any{path.source, path.response})
			}
		}
		shape, err := json.Marshal([]any{json.RawMessage(astKey), value.logic, value.client, value.private, value.columns, clients})
		if err != nil {
			b.Fatal(err)
		}
		shapes = append(shapes, string(shape))
	}
	slices.Sort(shapes)
	attestAwaitShape(b, shapes)
}

func TestAwaitQualifiedRuntimeSource(t *testing.T) {
	source := os.Getenv("LUXO_AWAIT_RUNTIME_SOURCE")
	output := os.Getenv("LUXO_AWAIT_RUNTIME_OUTPUT")
	if source == "" || output == "" {
		t.Skip("explicit isolated runtime output required")
	}
	data, err := os.ReadFile(source)
	if err != nil {
		t.Fatal(err)
	}
	input := analyzePermissionFixture(t, string(data))
	if len(input.Errors) != 0 {
		t.Fatal(input.Errors)
	}
	config := GeneratorConfig{Driver: DriverPG, IDs: completeFixtureAPIIDs(input, StableIDs{})}
	generated, err := Generate(input, "generated", config)
	if err != nil {
		t.Fatal(err)
	}
	for name, contents := range generated.Files {
		if filepath.Base(name) != name {
			t.Fatalf("unexpected generated path %q", name)
		}
		if err := os.WriteFile(filepath.Join(output, name), contents, 0600); err != nil {
			t.Fatal(err)
		}
	}
}
