#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
A = "3bb59ed140dfc959e4cb4419397a009536ea3f4c"
B = "1b8c73f81b2efccd4fba247e0ac4ce8ee11f8d24"
A_TREE = "9e93fb1d1b61e495088b345f834c7ed94ca89060"
HISTORY = HERE.parent / "await-release-candidate.x7pQ9jxS" / "benchmark-inventory.log"
CPU = "2"
BENCH_ROW = re.compile(r"^(Benchmark\S+)-\d+\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$", re.MULTILINE)
SHAPE_ROW = re.compile(r"^await-shape (Benchmark\S+) ([a-f0-9]{64})$", re.MULTILINE)
COMPILER_EXTRA = {
    "BenchmarkQueryValueDemand/query/for-query",
    "BenchmarkQueryValueDemand/load/load-literal",
    "BenchmarkLoadDemandGeneration/false/1",
    "BenchmarkLoadDemandGeneration/false/128",
    "BenchmarkQueryRelationLoopAnalysis/query/collected",
    "BenchmarkQueryRelationLoopAnalysis/query/yielded",
    "BenchmarkQueryRelationLoopGeneration/collected",
    "BenchmarkQueryRelationLoopGeneration/yielded",
    "BenchmarkPaginationCandidate/direct/Analyze",
    "BenchmarkPaginationCandidate/direct/Generate",
    "BenchmarkPaginationCandidate/object-nullable/Generate",
}
RUNTIME_LEAVES = {
    "equivalent": {"BenchmarkAwaitRuntimeEquivalent/normal", "BenchmarkAwaitRuntimeEquivalent/error"},
    "corrected": {"BenchmarkAwaitRuntimeCorrected/normal", "BenchmarkAwaitRuntimeCorrected/early",
                  "BenchmarkAwaitRuntimeCorrected/error"},
}

HOOK_GENERATE = "attestAwaitGenerated(b, input, config)"
HOOK_DEMAND = """if load {
    attestAwaitDemand(b, analyzeLoadProjections(declaration.Body, models, declaration.ReturnType))
} else {
    attestAwaitDemand(b, analyzeQueryRelations(declaration.Body, declaration.ReturnType, models, nil))
}"""
HOOK_LOAD_GENERATE = """qualified, err := generator.Generate(input, "generated", nil)
if err != nil { b.Fatal(err) }
attestAwaitShape(b, qualified.Files)"""
HOOKS = {
    "binding_scope_test.go": {"benchmarkBindingGeneration": [HOOK_GENERATE]},
    "codegen_bench_test.go": {"BenchmarkQueryFacadeSource": ["attestAwaitFacade(b, names, fields)"]},
    "compile_defaults_bench_test.go": {"BenchmarkNullableWhenGeneration": [HOOK_GENERATE]},
    "when_statement_bench_test.go": {
        "BenchmarkGenerateGenericWhenControls": [HOOK_GENERATE],
        "BenchmarkGenerateWhenExpressionThrows": [HOOK_GENERATE],
    },
    "load_selection_bench_test.go": {
        "BenchmarkQueryValueDemand": [HOOK_DEMAND], "BenchmarkQueryRelationLoopAnalysis": [HOOK_DEMAND],
        "BenchmarkQueryRelationLoopGeneration": [HOOK_LOAD_GENERATE], "BenchmarkLoadDemandGeneration": [HOOK_LOAD_GENERATE],
    },
    "compile_pagination_bench_test.go": {
        "BenchmarkPaginationCandidate": ["attestAwaitShape(b, semantic.Analyze([]*ast.File{file}).Files)", HOOK_GENERATE],
    },
}


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def instrument(filename, functions):
    source = filename.read_text()
    for function, hooks in functions.items():
        anchor = f"\nfunc {function}("
        if source.count(anchor) != 1:
            raise RuntimeError(f"missing exact hook target: {filename.name}/{function}")
        start = source.index(anchor)
        end = source.find("\nfunc ", start + len(anchor))
        end = len(source) if end < 0 else end
        fragment = source[start:end]
        targets = list(re.finditer(r"(?m)^([ \t]*)b\.ReportAllocs\(\)$", fragment))
        if len(targets) != len(hooks):
            raise RuntimeError(f"unexpected hook anchors: {filename.name}/{function}")
        for match, hook in reversed(list(zip(targets, hooks))):
            indent = match.group(1)
            added = [indent + "if qualifyAwaitShape() {"] + [indent + "\t" + line for line in hook.splitlines()] + [indent + "}"]
            fragment = fragment[:match.start()] + "\n".join(added) + "\n" + fragment[match.start():]
        source = source[:start] + fragment + source[end:]
    filename.write_text(source)


def pattern(names):
    return "|".join("/".join("^" + re.escape(part) + "$" for part in name.split("/")) for name in sorted(names))


def binary_args(binary, leaves, duration):
    return [str(binary), "-test.run=^$", "-test.bench=" + pattern(leaves), "-test.benchmem",
            "-test.count=1", f"-test.cpu={CPU}", f"-test.benchtime={duration}", "-test.timeout=3m"]


def log_process(args, logfile, env, cwd):
    result = subprocess.run(args, cwd=cwd, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logfile.write_text(result.stdout)
    return result


def smoke(binary, leaves, label, env, cwd, shapes=False, expected_pass=True):
    logfile = HERE / f"{label}.log"
    proof = "1" if shapes else ""
    result = log_process(binary_args(binary, leaves, "1x"), logfile, {**env, "LUXO_AWAIT_SHAPE_PROOF": proof}, cwd)
    if result.returncode:
        if expected_pass:
            raise RuntimeError(f"identity/output smoke failed: {logfile}")
        return {"exit": result.returncode, "log": logfile.name}
    values = {leaf: {"iterations": int(n), "ns/op": time, "B/op": int(bs), "allocs/op": int(alloc)}
              for leaf, n, time, bs, alloc in BENCH_ROW.findall(result.stdout)}
    if set(values) != leaves or any(row["iterations"] != 1 for row in values.values()):
        raise RuntimeError(f"unexpected benchmark work: {set(values) ^ leaves}")
    fingerprints = dict(SHAPE_ROW.findall(result.stdout))
    if shapes and set(fingerprints) != leaves:
        raise RuntimeError(f"missing identical-work attestation: {set(fingerprints) ^ leaves}")
    return {"exit": result.returncode, "log": logfile.name, "metrics": values, "shape": fingerprints}


def generated_files(directory):
    return {file.name: digest(file) for file in sorted(directory.glob("*.gen.go"))}


def prepare_runtime(compiler, source, arm, env, checkout, scratch):
    name = f"{arm}-{source}"
    src = scratch / source
    src.mkdir()
    runtime_env = {**env, "LUXO_AWAIT_RUNTIME_SOURCE": str(HERE / f"{source}.luxo"),
                   "LUXO_AWAIT_RUNTIME_OUTPUT": str(src)}
    result = log_process([str(compiler), "-test.run=^TestAwaitQualifiedRuntimeSource$"],
                         HERE / f"emit-{name}.log", runtime_env, checkout)
    if result.returncode:
        raise RuntimeError(f"cannot generate runtime input {name}")
    shutil.copyfile(HERE / f"runtime_{source}_test.go", src / "qualify_runtime_test.go")
    binary = HERE / f"runtime-{name}.test"
    result = log_process(["go", "test", "-c", "-trimpath", "-o", str(binary), "./" + str(src.relative_to(checkout))],
                         HERE / f"build-runtime-{name}.log", env, checkout)
    evidence = {"compileExit": result.returncode, "emitted": generated_files(src)}
    if result.returncode:
        if (arm, source) != ("A", "corrected") or "corrected(" not in (src/"app.gen.go").read_text():
            raise RuntimeError(f"could not compile expected runtime input {name}")
        binary.unlink(missing_ok=True)
        return evidence
    evidence["binary"] = {"path": binary.name, "sha256": digest(binary)}
    evidence["smoke"] = smoke(binary, RUNTIME_LEAVES[source], f"smoke-runtime-{name}", env, checkout,
                              expected_pass=(arm, source) != ("A", "corrected"))
    return evidence


def prepare_arm(arm, rev, compiler_leaves, base_env):
    with tempfile.TemporaryDirectory(dir=HERE, prefix=f"build-{arm}-") as temp:
        checkout = Path(temp)
        with subprocess.Popen(["git", "-C", str(ROOT), "archive", rev], stdout=subprocess.PIPE) as archive:
            with archive.stdout as stream:
                run("tar", "-xf", "-", "-C", temp, stdin=stream)
            if archive.wait():
                raise RuntimeError(f"could not extract tracked source {rev}")
        tool_tmp = checkout / ".tmp" / "tool"
        tool_tmp.mkdir(parents=True)
        env = {**base_env, "GOWORK": "off", "TMPDIR": str(tool_tmp), "GOTMPDIR": str(tool_tmp)}
        run("sh", "scripts/setup-modules.sh", temp, env=env, cwd=checkout)
        env["GOWORK"] = str(checkout / "go.work")
        package = checkout / "pkg/codegen"
        original = {path: digest(package/path) for path in HOOKS}
        for path, functions in HOOKS.items():
            instrument(package/path, functions)
        fixture = package / "qualification_fixture_test.go"
        shutil.copyfile(HERE / fixture.name, fixture)
        run("gofmt", "-s", "-w", str(fixture), *(str(package/path) for path in HOOKS))
        binary = HERE / f"compiler-{arm}.test"
        run("go", "test", "-c", "-trimpath", "-o", str(binary), "./pkg/codegen", env=env, cwd=checkout)
        compiler = smoke(binary, compiler_leaves, f"smoke-compiler-{arm}", env, checkout, shapes=True)
        runtime = {kind: prepare_runtime(binary, kind, arm, env, checkout, checkout/".tmp") for kind in RUNTIME_LEAVES}
        return {"revision": rev, "compiler": {"path": binary.name, "sha256": digest(binary), **compiler},
                "runtime": runtime, "trackedBenchmarkSourceSHA256": original}


def product():
    lines = HISTORY.read_text().splitlines()
    historical = {re.sub(r"-\d+$", "", line.split()[0]) for line in lines if line.startswith("Benchmark")}
    if len(historical) != 24 or historical & COMPILER_EXTRA:
        raise RuntimeError("old inventory receipt changed")
    return historical | COMPILER_EXTRA


def prepare():
    if git("rev-parse", A + "^{tree}") != A_TREE or git("cat-file", "-t", B) != "tree":
        raise RuntimeError("exact source revisions unavailable")
    env = {
        **os.environ, "GOTOOLCHAIN": "local", "GOPROXY": "off", "GOSUMDB": "off",
        "GOMAXPROCS": CPU, "GOFLAGS": "-p=1", "CGO_ENABLED": "0",
    }
    for key in list(env):
        if key.startswith("LUXO_") or key in ("GOOS", "GOARCH", "GOWORK", "GOGC", "GODEBUG", "GOMEMLIMIT"):
            env.pop(key)
    ver = subprocess.check_output(["go", "version"], env=env, text=True).strip()
    if not ver.startswith("go version go1.27.1 "):
        raise RuntimeError("unexpected Go toolchain")
    leaves = product()
    arms = {arm: prepare_arm(arm, rev, leaves, env) for arm, rev in (("A", A), ("B", B))}
    old, new = arms["A"], arms["B"]
    if old["trackedBenchmarkSourceSHA256"] != new["trackedBenchmarkSourceSHA256"]:
        raise RuntimeError("benchmark sources differ between trees")
    matches = sorted(leaf for leaf in leaves if old["compiler"]["shape"][leaf] == new["compiler"]["shape"][leaf])
    changed = sorted(leaves - set(matches))
    old_compatible, new_compatible = (arm["runtime"]["equivalent"] for arm in arms.values())
    if old_compatible["emitted"] != new_compatible["emitted"]:
        raise RuntimeError("normal/error comparable runtime generated different files")
    old_corrected = old["runtime"]["corrected"]
    if not old_corrected["compileExit"] and not old_corrected["smoke"]["exit"]:
        raise RuntimeError("candidate-only boundary did not distinguish behavior")
    receipt = {"baseCommit": A, "baseTree": A_TREE, "candidate": B, "go": ver, "cpuFlag": int(CPU),
               "arms": arms, "split": {"pairedCompiler": matches, "changedCompilerShape": changed,
               "pairedRuntime": sorted(RUNTIME_LEAVES["equivalent"]), "candidateOnlyRuntime": sorted(RUNTIME_LEAVES["corrected"])},
               "fixtureSHA256": {file.name: digest(file) for file in sorted(HERE.glob("*.go")) + sorted(HERE.glob("*.luxo"))},
               "driverSHA256": digest(Path(__file__)), "historicalInventorySHA256": digest(HISTORY),
               "classification": "1x smoke only"}
    (HERE/"prepared.json").write_text(json.dumps(receipt, indent=2) + "\n")


def command(arm, phase):
    receipt = json.loads((HERE/"prepared.json").read_text())
    if receipt["driverSHA256"] != digest(Path(__file__)):
        raise RuntimeError("driver differs from the qualified version")
    target = receipt["arms"][arm]
    if phase == "compiler":
        binary = target["compiler"]
        leaves = receipt["split"]["pairedCompiler"]
    else:
        if phase == "corrected" and arm != "B":
            raise RuntimeError("corrected runtime has only a candidate executable")
        name = "pairedRuntime" if phase == "equivalent" else "candidateOnlyRuntime"
        binary = target["runtime"][phase]["binary"]
        leaves = receipt["split"][name]
    file = HERE / binary["path"]
    if digest(file) != binary["sha256"]:
        raise RuntimeError(f"{file} differs from the qualified executable")
    if not leaves:
        raise RuntimeError("empty equivalence set")
    env = ["env", "-u", "LUXO_AWAIT_SHAPE_PROOF", "-u", "LUXO_GENERIC_WHEN_OUTPUT",
           f"GOMAXPROCS={CPU}", "GOGC=100", "GOMEMLIMIT=off", "GODEBUG="]
    print(shlex.join(env + binary_args(file, leaves, "100ms")))


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)
    sub.add_parser("prepare")
    cmd = sub.add_parser("command")
    cmd.add_argument("arm", choices=("A", "B"))
    cmd.add_argument("phase", choices=("compiler", "equivalent", "corrected"))
    args = parser.parse_args()
    if HERE.parent.name != "review-by-file":
        raise RuntimeError("driver must remain inside its task scratch")
    os.umask(0o077)
    if args.mode == "prepare":
        prepare()
    else:
        command(args.arm, args.phase)


if __name__ == "__main__":
    main()
